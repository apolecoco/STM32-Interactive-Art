/**
  ******************************************************************************
  * @ 名称  STM32 学习模板
  * @ 版本  STD 库 V3.5.0
  * @ 描述  适用于嵌入式虚拟仿真平台
  *         
  * @ 注意  本程序只供学习使用
  ******************************************************************************
  */


#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"
#include "adc.h"
// 包含我们新创建的应用显示模块
#include "app_display.h" 
#include "app_light.h"

int main(void) {
    // 系统基础初始化
    // ADC初始化 - 使用DMA多通道配置（支持PA0-PA4）
    ADC1_DMA_Config();  // 就是在这里修改！调用这个函数而不是 Adc_Init()
    // 应用显示初始化
    AppDisplay_Init();

    WS2812_Init();  // 初始化灯带
    
    // 测试灯带
    // 先测试稳定性
    WS2812_StabilityTest();
    delay_ms(1000);
    
    // 测试可靠颜色
    WS2812_ReliableColors();
    delay_ms(1000);
    // 主循环
    while (1) {
       AppDisplay_Update(); // 更新显示
       delay_ms(1000);      // 延时1秒
    }
}

