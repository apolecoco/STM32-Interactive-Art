#ifndef __APP_DISPLAY_H
#define __APP_DISPLAY_H

#include "stm32f10x.h"

void AppDisplay_Init(void);
void AppDisplay_Update(void);

#endif