#include "app_display.h"
#include "iic_oled.h"
#include "led.h"
#include "dht11.h"
#include "MQ_Sensor.h"  // 新增MQ传感器头文件
#include "delay.h"
#include <stdio.h>

// 添加这行：声明外部ADC DMA缓冲区变量
extern volatile unsigned short int ADC_ConvertedValue[5];

static int display_count = 0;
static int temperature = 0;
static int humidity = 0;
static float air_quality = 0.0;  // 新增空气质量变量

void AppDisplay_Init(void) {
    LED_Init();
    IIC_OLED_Init();
    
    // 初始化DHT11并检查是否存在
    if (DHT11_Init() == 0) {
        IIC_OLED_Clear();
        IIC_OLED_ShowString(0, 0, "Sensors Ready!");
    } else {
        IIC_OLED_Clear();
        IIC_OLED_ShowString(0, 0, "DHT11 Error!");
    }
    delay_ms(1000);
    IIC_OLED_Clear();
}

void AppDisplay_Update(void) {
    char disp_str[24];
    static uint8_t display_page = 0;
    
    // LED闪烁指示系统运行
    GPIO_WriteBit(GPIOC, GPIO_Pin_13, (BitAction)(1 - GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13)));
    
    // 读取传感器数据
    uint8_t dht11_success = (DHT11_Read_Data(&temperature, &humidity) == 0);
    u16 raw_adc = ADC_ConvertedValue[4];
    air_quality = (float)raw_adc * 3.3f / 4095.0f;
    
    IIC_OLED_Clear();
    
    // 每5秒切换一屏
    if (display_count % 3 == 0) {
        display_page = (display_page + 1) % 3;
    }
    
    switch (display_page) {
        case 0: // 环境数据屏
            IIC_OLED_ShowString(0, 0, "= Environment =");
            if (dht11_success) {
                sprintf(disp_str, "Temp: %d.%dC", temperature/10, abs(temperature%10));
                IIC_OLED_ShowString(0, 2, disp_str);
                sprintf(disp_str, "Humi: %d.%d%%", humidity/10, humidity%10);
                IIC_OLED_ShowString(0, 4, disp_str);
            } else {
                IIC_OLED_ShowString(0, 2, "Sensor Reading...");
            }
            break;
            
        case 1: // 空气质量屏
            IIC_OLED_ShowString(0, 0, "= Air Quality =");
            sprintf(disp_str, "Voltage: %.2fV", air_quality);
            IIC_OLED_ShowString(0, 2, disp_str);
            
            // 空气质量评价
            if (air_quality < 1.2) {
                IIC_OLED_ShowString(0, 4, "Status:Excellent");
            } else if (air_quality < 1.6) {
                IIC_OLED_ShowString(0, 4, "Status:Good");
            } else if (air_quality < 2.0) {
                IIC_OLED_ShowString(0, 4, "Status:Moderate");
            } else {
                IIC_OLED_ShowString(0, 4, "Status:Poor!");
            }
            break;
            
        case 2: // 系统状态屏
            IIC_OLED_ShowString(0, 0, "= System Info =");
            sprintf(disp_str, "ADC Raw: %d", raw_adc);
            IIC_OLED_ShowString(0, 2, disp_str);
            sprintf(disp_str, "Run Time: %d", display_count);
            IIC_OLED_ShowString(0, 4, disp_str);
            IIC_OLED_ShowString(0, 6, "LightShadowv1.0");
            break;
    }
    
    display_count++;
    delay_ms(2000);
}