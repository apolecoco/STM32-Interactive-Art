#include "app_light.h"
#include "delay.h"

static uint32_t light_counter = 0;

void Light_Init(void) {
    WS2812_Init();
}

// 测试序列：展示所有基础颜色
void Light_TestSequence(void) {
    RGB_Color colors[] = {COLOR_RED, COLOR_GREEN, COLOR_BLUE, COLOR_WHITE, COLOR_OFF};
    
    for (int i = 0; i < 5; i++) {
        WS2812_SetAll(colors[i]);
        WS2812_Update();
        delay_ms(500);
    }
}

// 根据环境数据生成光影效果
void Light_UpdateFromEnvironment(int temp, int humi, float air_quality) {
    RGB_Color base_color;
    
    // 根据温度决定基色
    if (temp < 200) { // < 20°C: 冷色调 (蓝色)
        base_color = (RGB_Color){0, 0, 255};
    } else if (temp > 280) { // > 28°C: 暖色调 (红色)
        base_color = (RGB_Color){0, 255, 0};
    } else { // 20-28°C: 舒适色调 (绿色)
        base_color = (RGB_Color){255, 0, 0};
    }
    
    // 根据空气质量添加效果
    if (air_quality > 1.8) {
        // 污染时闪烁警示
        if ((light_counter / 10) % 2) {
            WS2812_SetAll(base_color);
        } else {
            WS2812_SetAll(COLOR_OFF);
        }
    } else {
        // 空气质量好时正常显示
        WS2812_SetAll(base_color);
    }
    
    WS2812_Update();
    light_counter++;
}