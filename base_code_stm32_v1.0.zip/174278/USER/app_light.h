#ifndef __APP_LIGHT_H
#define __APP_LIGHT_H

#include "ws2812.h"

void Light_Init(void);
void Light_UpdateFromEnvironment(int temp, int humi, float air_quality);
void Light_TestSequence(void);

#endif