#ifndef __PWM_H
#define __PWM_H

#include "sys.h"

// 初始化定时器 3 为 PWM 输出
void PWM_Init(void);

#endif
