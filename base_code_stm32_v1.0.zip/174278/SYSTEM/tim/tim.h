#ifndef __TIM_H
#define __TIM_H

#include "sys.h"

// 初始化定时器1
void TIM1_Init(void);
// 初始化定时器2
void TIM2_Init(void);

#endif
