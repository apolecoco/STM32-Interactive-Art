#ifndef __CHFONT_H
#define __CHFONT_H	

//PCtolcd2002 ����->����16 ����������ͬOLEDʵ�顣
extern const u8 tfont16[][16];
extern const u8 text_temperature[][16];
extern const u8 text_humidity[][16];
extern const u8 text_airQuality[][16];
extern const u8 text_airPressure[][16];
extern const u8 text_altitude[][16];
extern const u8 text_GYMCU680[][24];
extern const u8 text_bottom1[][24];
extern const u8 text_bottom2[][24];

#endif
