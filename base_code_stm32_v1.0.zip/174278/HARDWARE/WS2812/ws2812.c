#include "ws2812.h"
#include "delay.h"

// WS2812数据缓冲区 (每个灯珠需要24bit = 3字节)
static uint8_t ws2812_buffer[LED_NUM * 3];

// 初始化GPIO
void WS2812_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin = LED_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(LED_PORT, &GPIO_InitStructure);
    
    GPIO_SetBits(LED_PORT, LED_PIN);  // 默认高电平
    
    // 清空缓冲区
    WS2812_Clear();
}

// 设置单个灯珠颜色
void WS2812_SetColor(uint8_t index, RGB_Color color) {
    if (index >= LED_NUM) return;
    
    uint8_t *p = &ws2812_buffer[index * 3];
    p[0] = color.g;  // G
    p[1] = color.r;  // R
    p[2] = color.b;  // B
}

// 设置所有灯珠为同一颜色
void WS2812_SetAll(RGB_Color color) {
    for (uint8_t i = 0; i < LED_NUM; i++) {
        WS2812_SetColor(i, color);
    }
}

// 清空所有灯珠
void WS2812_Clear(void) {
    for (uint8_t i = 0; i < sizeof(ws2812_buffer); i++) {
        ws2812_buffer[i] = 0;
    }
}

// 更稳定的延时函数
static void WS2812_Delay(uint32_t cycles) {
    volatile uint32_t i = cycles;
    while(i--) {
        __asm__("nop");  // 插入空指令，增加稳定性
    }
}
// 重写发送函数，增加时序容错
static void WS2812_SendByte(uint8_t byte) {
    for (int8_t bit = 7; bit >= 0; bit--) {
        if (byte & (1 << bit)) {
            // 发送'1': 稍微延长高电平时间
            GPIO_SetBits(LED_PORT, LED_PIN);
            WS2812_Delay(25);  // 增加延时
            GPIO_ResetBits(LED_PORT, LED_PIN);
            WS2812_Delay(9);   // 减少低电平时间
        } else {
            // 发送'0': 保持较短高电平
            GPIO_SetBits(LED_PORT, LED_PIN);
            WS2812_Delay(9);   // 较短高电平
            GPIO_ResetBits(LED_PORT, LED_PIN);
            WS2812_Delay(25);  // 较长低电平
        }
    }
}

// 增加复位时间
void WS2812_Update(void) {
    __disable_irq();  // 禁用中断
    
    // 发送数据前先确保低电平
    GPIO_ResetBits(LED_PORT, LED_PIN);
    WS2812_Delay(100);
    
    for (uint16_t i = 0; i < sizeof(ws2812_buffer); i++) {
        WS2812_SendByte(ws2812_buffer[i]);
    }
    
    // 延长复位信号
    GPIO_ResetBits(LED_PORT, LED_PIN);
    WS2812_Delay(1500);  // 显著增加复位时间
    
    __enable_irq();
}

// 测试模式：显示彩虹色
void WS2812_TestPattern(void) {
    RGB_Color test_colors[8] = {
        COLOR_RED, COLOR_GREEN, COLOR_BLUE,
        COLOR_YELLOW, COLOR_CYAN, COLOR_MAGENTA,
        COLOR_WHITE, COLOR_OFF
    };
    
    for (uint8_t i = 0; i < LED_NUM; i++) {
        WS2812_SetColor(i, test_colors[i]);
    }
}

// 逐步测试函数 - 新增的调试函数
void WS2812_DebugTest(void) {
    // 测试1: 只点亮第一个灯珠红色
    WS2812_SetColor(0, COLOR_RED);
    WS2812_SetColor(1, COLOR_OFF);
    WS2812_SetColor(2, COLOR_OFF);
    WS2812_SetColor(3, COLOR_OFF);
    WS2812_SetColor(4, COLOR_OFF);
    WS2812_SetColor(5, COLOR_OFF);
    WS2812_SetColor(6, COLOR_OFF);
    WS2812_SetColor(7, COLOR_OFF);
    WS2812_Update();
    delay_ms(2000);
    
    // 测试2: 只点亮第二个灯珠绿色
    WS2812_SetColor(0, COLOR_OFF);
    WS2812_SetColor(1, COLOR_GREEN);
    WS2812_Update();
    delay_ms(2000);
    
    // 测试3: 所有灯珠蓝色
    WS2812_SetAll(COLOR_BLUE);
    WS2812_Update();
    delay_ms(2000);
    
    // 测试4: 彩虹测试
    WS2812_TestPattern();
    WS2812_Update();
    delay_ms(2000);
    
    // 测试5: 全部关闭
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
    delay_ms(1000);
}
// 测试不同的颜色顺序
void WS2812_ColorOrderTest(void) {
    // 测试1: 纯红色 (尝试不同编码)
    //printf("Testing RED - GRB order\n");
    WS2812_SetAll((RGB_Color){0, 255, 0});  // GRB: 红色
    WS2812_Update();
    delay_ms(2000);
    
    // 测试2: 纯绿色
    //printf("Testing GREEN - GRB order\n");
    WS2812_SetAll((RGB_Color){255, 0, 0});  // GRB: 绿色
    WS2812_Update();
    delay_ms(2000);
    
    // 测试3: 纯蓝色
    //printf("Testing BLUE - GRB order\n");
    WS2812_SetAll((RGB_Color){0, 0, 255});  // GRB: 蓝色
    WS2812_Update();
    delay_ms(2000);
    
    // 测试4: 尝试RGB顺序
    //printf("Testing RGB order\n");
    WS2812_SetAll((RGB_Color){255, 0, 0});  // 如果是RGB顺序，这应该是红色
    WS2812_Update();
    delay_ms(2000);
    
    WS2812_SetAll((RGB_Color){0, 255, 0});  // 如果是RGB顺序，这应该是绿色
    WS2812_Update();
    delay_ms(2000);
    
    // 全部关闭
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}

// 稳定性测试 - 重复发送相同颜色
void WS2812_StabilityTest(void) {
    for (int repeat = 0; repeat < 10; repeat++) {
        // 测试1: 所有灯珠红色
        WS2812_SetAll((RGB_Color){0, 255, 0});  // GRB: 红色
        WS2812_Update();
        delay_ms(500);
        
        // 测试2: 所有灯珠绿色  
        WS2812_SetAll((RGB_Color){255, 0, 0});  // GRB: 绿色
        WS2812_Update();
        delay_ms(500);
        
        // 测试3: 所有灯珠蓝色
        WS2812_SetAll((RGB_Color){0, 0, 255});  // GRB: 蓝色
        WS2812_Update();
        delay_ms(500);
    }
    
    // 最后关闭
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}

// 简单可靠的颜色映射（基于你的观察）
void WS2812_ReliableColors(void) {
    // 使用我们观察到的可靠颜色组合
    RGB_Color reliable_red = {0, 200, 0};     // GRB
    RGB_Color reliable_green = {200, 0, 0};   // GRB  
    RGB_Color reliable_blue = {0, 0, 200};    // GRB
    
    // 分别点亮不同颜色的灯珠
    WS2812_SetColor(0, reliable_red);
    WS2812_SetColor(1, reliable_green);
    WS2812_SetColor(2, reliable_blue);
    WS2812_SetColor(3, reliable_red);
    WS2812_SetColor(4, reliable_green);
    WS2812_SetColor(5, reliable_blue);
    WS2812_SetColor(6, reliable_red);
    WS2812_SetColor(7, reliable_green);
    
    WS2812_Update();
    delay_ms(3000);
    
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}
