#ifndef __MQ_SENSOR_H
#define __MQ_SENSOR_H
#include <math.h>
#include <stdio.h>

#include "sys.h"
#include "adc.h"
#include "delay.h"

float GetMQ8Out(void);
float GetMQ135Out(void);
// 安全的MQ135读取函数（简化版，避免阻塞）
float GetMQ135Out_Safe(void);


float GetMQ136Out(void);
float GetMQ137Out(void);
float GetMQ138Out(void);

#endif