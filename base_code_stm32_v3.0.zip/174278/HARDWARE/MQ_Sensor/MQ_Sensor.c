#include "MQ_Sensor.h"

extern volatile unsigned short int ADC_ConvertedValue[5];
static unsigned int adc_value = 0; //保存ADC数值

//MQ8数据获取
float GetMQ8Out(void)
{
    double volt = 0;
    double ppm = 0;
    
    delay_ms(20);
    
    //adc数值
    adc_value = Get_Adc(1);
    printf("adcvalue = %d.\n",adc_value);

    
    //adc输出电压
    volt=(double)adc_value*3.3/4095;
    printf("volt = %f.\n",volt);
    
    //根据电压值换算成被检测气体的污染指数

    // MQ135 MQ8 H2 空气质量 通用 
    // volt = ((3.65*pow(ppm,0.3203*2))/(34.88+pow(ppm,0.3203*2))+0.6);
    ppm = pow(10, (log10(34.88*(volt-0.6)/(3.65-volt+0.6)))/(0.3203*2));

    printf("ppm = %f.\n\n",ppm);
    return volt;
}

//MQ135数据获取
float GetMQ135Out(void)
{
    double volt = 0;
    double ppm = 0;
    
    delay_ms(20);
    
    //adc数值
    adc_value = ADC_ConvertedValue[1];  // 使用DMA缓冲区中的通道1数据
    printf("adcvalue = %d.\n",adc_value);

    
    //adc输出电压
    volt=(double)adc_value*3.3/4095;
    printf("volt = %f.\n",volt);
    
    //根据电压值换算成被检测气体的污染指数

    // MQ135 MQ8 H2 空气质量 通用 
    // volt = ((3.65*pow(ppm,0.3203*2))/(34.88+pow(ppm,0.3203*2))+0.6);
    ppm = pow(10, (log10(34.88*(volt-0.6)/(3.65-volt+0.6)))/(0.3203*2));

    printf("ppm = %f.\n\n",ppm);
    return volt;
}

// 安全的MQ135读取函数（简化版，避免阻塞）
float GetMQ135Out_Safe(void)
{
    // 直接从DMA缓冲区读取通道1的数据
    u16 raw_value = ADC_ConvertedValue[4];
    
    // 简单的数据有效性检查
    if (raw_value == 0 || raw_value >= 4095) {
        return 0.5f; // 返回默认安全值
    }
    
    // 转换为电压值
    float voltage = (float)raw_value * 3.3f / 4095.0f;
    
    // 电压范围检查
    if (voltage < 0.1f || voltage > 3.0f) {
        return 0.5f; // 返回默认安全值
    }
    
    return voltage;
}

//MQ136数据获取
float GetMQ136Out(void)
{
    double volt = 0;
    double ppm = 0;
    
    delay_ms(20);
    
    //adc数值
    adc_value = Get_Adc(1);
    printf("adcvalue = %d.\n",adc_value);

    
    //adc输出电压
    volt=(double)adc_value*3.3/4095;
    printf("volt = %f.\n",volt);
    
    //根据电压值换算成被检测气体的污染指数
    //MQ136~138 H2S NH3 PA 通用
    // volt = ((2.3*pow(4*ppm,0.3203*2))/(34.88+pow(4*ppm,0.3203*2))+0.6); 
    ppm = (pow(10, (log10(34.88*(volt-0.6)/(2.3-volt+0.6)))/(0.3203*2)))/4;


    printf("ppm = %f.\n\n",ppm);
    return volt;
}

//MQ137数据获取
float GetMQ137Out(void)
{
    double volt = 0;
    double ppm = 0;
    
    delay_ms(20);
    
    //adc数值
    adc_value = Get_Adc(1);
    printf("adcvalue = %d.\n",adc_value);

    
    //adc输出电压
    volt=(double)adc_value*3.3/4095;
    printf("volt = %f.\n",volt);
    
    //根据电压值换算成被检测气体的污染指数
    //MQ136~138 H2S NH3 PA 通用
    // volt = ((2.3*pow(4*ppm,0.3203*2))/(34.88+pow(4*ppm,0.3203*2))+0.6); 
    ppm = (pow(10, (log10(34.88*(volt-0.6)/(2.3-volt+0.6)))/(0.3203*2)))/4;


    printf("ppm = %f.\n\n",ppm);
    return volt;
}

//MQ138数据获取
float GetMQ138Out(void)
{
    double volt = 0;
    double ppm = 0;
    
    delay_ms(20);
    
    //adc数值
    adc_value = Get_Adc(1);
    printf("adcvalue = %d.\n",adc_value);

    
    //adc输出电压
    volt=(double)adc_value*3.3/4095;
    printf("volt = %f.\n",volt);
    
    //根据电压值换算成被检测气体的污染指数
    //MQ136~138 H2S NH3 PA 通用
    // volt = ((2.3*pow(4*ppm,0.3203*2))/(34.88+pow(4*ppm,0.3203*2))+0.6); 
    ppm = (pow(10, (log10(34.88*(volt-0.6)/(2.3-volt+0.6)))/(0.3203*2)))/4;


    printf("ppm = %f.\n\n",ppm);
    return volt;
}