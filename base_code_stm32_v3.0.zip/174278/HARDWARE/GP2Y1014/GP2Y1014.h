#ifndef __GP2Y1014_H
#define __GP2Y1014_H
#include <math.h>
#include <stdio.h>

#include "sys.h"
#include "adc.h"
#include "delay.h"

void GetGP2Y ( void );

#endif