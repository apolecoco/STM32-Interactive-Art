#include "app_light.h"
#include "delay.h"

static uint32_t light_counter = 0;
static uint8_t current_mode = MODE_ENVIRONMENT; // 默认环境模式

void Light_Init(void) {
    WS2812_Init();
    // 启动时显示初始化完成
    WS2812_SetAll((RGB_Color){0, 100, 0}); // 柔和的绿色
    WS2812_Update();
    delay_ms(500);
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}

static RGB_Color MapTemperatureToColor(int temperature) {
    // 使用修正后的RGB颜色
    if (temperature < 200) { // < 20°C: 蓝色
        return COLOR_BLUE;
    } else if (temperature < 250) { // 20-25°C: 绿色
        return COLOR_GREEN;
    } else if (temperature < 280) { // 25-28°C: 黄色
        return COLOR_YELLOW;
    } else { // > 28°C: 红色
        return COLOR_RED;
    }
}

// 环境自适应模式
static void Light_EnvironmentMode(int temp, int humi, float air_quality) {
    RGB_Color base_color = MapTemperatureToColor(temp);
    
    // 根据空气质量添加效果
    if (air_quality > 1.8) {
        // 污染时红色闪烁警示
        if ((light_counter / 8) % 2) {
            WS2812_SetAll((RGB_Color){0, 200, 0}); // 红色警示
        } else {
            WS2812_SetAll(COLOR_OFF);
        }
    } else if (air_quality > 1.4) {
        // 中等质量时呼吸效果
        uint8_t brightness = (light_counter % 100) < 50 ? 
                            (light_counter % 100) * 2 : 
                            (100 - (light_counter % 100)) * 2;
        
        RGB_Color breath_color = {
            base_color.g * brightness / 100,
            base_color.r * brightness / 100, 
            base_color.b * brightness / 100
        };
        WS2812_SetAll(breath_color);
    } else {
        // 空气质量好时稳定显示
        WS2812_SetAll(base_color);
    }
}

// 专注模式 - 冷色调缓慢呼吸
static void Light_FocusMode(void) {
    uint8_t brightness = (light_counter % 150) < 75 ? 
                        (light_counter % 150) * 1.5 : 
                        (150 - (light_counter % 150)) * 1.5;
    
    RGB_Color focus_color = {0, 0, brightness}; // 蓝色呼吸
    WS2812_SetAll(focus_color);
}

// 放松模式 - 暖色调流动效果
static void Light_RelaxMode(void) {
    for (int i = 0; i < LED_NUM; i++) {
        uint8_t phase = (light_counter * 2 + i * 30) % 360;
        uint8_t brightness = (phase < 180) ? phase * 1.4 : (360 - phase) * 1.4;
        
        RGB_Color relax_color = {brightness, brightness / 2, 0}; // 橙黄色流动
        WS2812_SetColor(i, relax_color);
    }
}

// 主更新函数
void Light_UpdateFromEnvironment(int temp, int humi, float air_quality) {
    RGB_Color base_color;
    
    printf("Light Module - T:%d, Color Mapping...\r\n", temp);
    
    // 根据温度决定基色
    if (temp < 200) { // < 20°C: 冷色调
        base_color = COLOR_BLUE;
        printf("Color: BLUE (Cold)\r\n");
    } else if (temp < 250) { // 20-25°C: 舒适色调
        base_color = COLOR_GREEN;  
        printf("Color: GREEN (Comfort)\r\n");
    } else if (temp < 280) { // 25-28°C: 温暖色调
        base_color = COLOR_YELLOW;
        printf("Color: YELLOW (Warm)\r\n");
    } else { // > 28°C: 热色调
        base_color = COLOR_RED;
        printf("Color: RED (Hot)\r\n");
    }
    
    // 根据空气质量添加效果
    if (air_quality > 1.8) {
        // 污染时红色闪烁警示
        static uint8_t blink = 0;
        blink = !blink;
        if (blink) {
            WS2812_SetAll(COLOR_RED);
            printf("Effect: RED BLINK (Pollution)\r\n");
        } else {
            WS2812_SetAll(COLOR_OFF);
        }
    } else {
        // 空气质量好时正常显示
        WS2812_SetAll(base_color);
        printf("Effect: Steady Color\r\n");
    }
    
    WS2812_Update();
}

// 切换模式
void Light_SetMode(uint8_t mode) {
    current_mode = mode;
    // 模式切换时短暂显示确认效果
    RGB_Color mode_color;
    switch (mode) {
        case MODE_ENVIRONMENT: mode_color = (RGB_Color){100, 100, 100}; break; // 白色
        case MODE_FOCUS: mode_color = (RGB_Color){0, 0, 200}; break;      // 蓝色
        case MODE_RELAX: mode_color = (RGB_Color){150, 100, 0}; break;    // 橙色
        default: mode_color = (RGB_Color){100, 100, 100}; break;
    }
    
    WS2812_SetAll(mode_color);
    WS2812_Update();
    delay_ms(300);
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
    delay_ms(100);
}

// 颜色调试函数
void Light_DebugTest(void) {
    //printf("=== Light Debug Test ===\n");
    
    // 测试纯红色
    //printf("Testing PURE RED\n");
    WS2812_SetAll((RGB_Color){0, 255, 0});  // GRB顺序：红色
    WS2812_Update();
    delay_ms(3000);
    
    // 测试纯绿色
    //printf("Testing PURE GREEN\n");  
    WS2812_SetAll((RGB_Color){255, 0, 0});  // GRB顺序：绿色
    WS2812_Update();
    delay_ms(3000);
    
    // 测试纯蓝色
    //printf("Testing PURE BLUE\n");
    WS2812_SetAll((RGB_Color){0, 0, 255});  // GRB顺序：蓝色
    WS2812_Update();
    delay_ms(3000);
    
    // 测试白色
    //printf("Testing WHITE\n");
    WS2812_SetAll((RGB_Color){255, 255, 255});  // GRB顺序：白色
    WS2812_Update();
    delay_ms(3000);
    
    // 关闭
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}