#ifndef __APP_LIGHT_H
#define __APP_LIGHT_H

#include "ws2812.h"

// 模式定义
#define MODE_ENVIRONMENT 0
#define MODE_FOCUS       1
#define MODE_RELAX       2

void Light_Init(void);
void Light_UpdateFromEnvironment(int temp, int humi, float air_quality);
void Light_SetMode(uint8_t mode);
void Light_DebugTest();

#endif