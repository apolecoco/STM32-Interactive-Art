/**
  ******************************************************************************
  * @ 名称  STM32 学习模板
  * @ 版本  STD 库 V3.5.0
  * @ 描述  适用于嵌入式虚拟仿真平台
  *         
  * @ 注意  本程序只供学习使用
  ******************************************************************************
  */


#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"
#include "adc.h"
#include "stm32f10x_conf.h"
#include "usart.h"
// 包含我们新创建的应用显示模块
#include "app_display.h" 
#include "app_light.h"


// 全局传感器数据
static int current_temp = 0;
static int current_humi = 0; 
static float current_air = 0.0;

int main(void) {
    // 系统初始化
    ADC1_DMA_Config();
    AppDisplay_Init();
    Light_Init();
    uart_init(115200);
    // 启动时显示模式提示

    printf("=== Getter Functions Test ===\r\n");
    printf("Using proper data access methods\r\n");
    
    // 测试获取函数
    printf("Initial Getter Values - T:%d, H:%d, A:%.2f\r\n",
           GetCurrentTemperature(), GetCurrentHumidity(), GetCurrentAirQuality());
    while (1) {
        // 更新显示（同时获取传感器数据）
        AppDisplay_Update();
        
        // 使用获取函数访问数据
        int temp = GetCurrentTemperature();
        int humi = GetCurrentHumidity();
        float air = GetCurrentAirQuality();
        
        printf("Main via Getters - T:%d, H:%d, A:%.2f\r\n", temp, humi, air);
        // 更新光影效果
        // 传递给光影模块
        Light_UpdateFromEnvironment(temp, humi, air);
        
        delay_ms(2000); // 快速更新光影效果
    }
}
