#ifndef __BKP_H
#define __BKP_H

#include "sys.h"
#include "stm32f10x_conf.h"
#include "stm32f10x_bkp.h"

void TAMPER_Init(void);
	

#endif

