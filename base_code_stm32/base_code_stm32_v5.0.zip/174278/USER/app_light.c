#include "app_light.h"
#include "delay.h"
#include "usart.h"
#include "Tran.h"  // 添加超声波头文件
#include <math.h>


static uint32_t light_counter = 0;
uint8_t graffiti_active = 0;  // 改为全局变量
uint32_t graffiti_timeout = 0;
static uint8_t current_mode = MODE_ENVIRONMENT;  // 统一为一个current_mode

void Light_Init(void) {
    WS2812_Init();
    WS2812_SetAll((RGB_Color){0, 100, 0});
    WS2812_Update();
    delay_ms(500);
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}

static RGB_Color MapTemperatureToColor(int temperature) {
    if (temperature < 200) {
        return (RGB_Color){0, 0, 255};
    } else if (temperature < 250) {
        return (RGB_Color){0, 255, 0};
    } else if (temperature < 280) {
        return (RGB_Color){255, 255, 0};
    } else {
        return (RGB_Color){255, 0, 0};
    }
}

// Environment mode
static void Light_EnvironmentMode(int temp, int humi, float air_quality) {
    RGB_Color base_color = MapTemperatureToColor(temp);
    
    if (air_quality > 1.8) {
        if ((light_counter / 10) % 2) {
            WS2812_SetAll((RGB_Color){255, 0, 0});
        } else {
            WS2812_SetAll(COLOR_OFF);
        }
    } else {
        WS2812_SetAll(base_color);
    }
}

// Focus mode
static void Light_FocusMode(void) {
    uint8_t phase = light_counter % 25;
    uint8_t brightness;
    
    if (phase < 13) {
        brightness = phase * 20;
    } else {
        brightness = (25 - phase) * 20;
    }
    
    RGB_Color focus_color = {0, 0, brightness};
    WS2812_SetAll(focus_color);
}

// Relax mode
static void Light_RelaxMode(void) {
    uint8_t base_pos = light_counter % (LED_NUM * 2);
    
    for (int i = 0; i < LED_NUM; i++) {
        uint8_t pos = (base_pos + i) % (LED_NUM * 2);
        uint8_t brightness = (pos < LED_NUM) ? 255 : 0;
        
        RGB_Color relax_color = {brightness, brightness / 2, 0};
        WS2812_SetColor(i, relax_color);
    }
}

// Party mode
static void Light_PartyMode(void) {
    static uint32_t beat_counter = 0;
    beat_counter++;
    
    uint16_t audio_level = (sin(beat_counter * 0.2) + 1) * 128;
    
    if (audio_level > 200) {
        for (int i = 0; i < LED_NUM; i++) {
            uint8_t hue = (beat_counter * 20 + i * 32) % 255;
            RGB_Color color;
            
            if (hue < 85) {
                color = (RGB_Color){hue * 3, 255 - hue * 3, 0};
            } else if (hue < 170) {
                hue -= 85;
                color = (RGB_Color){255 - hue * 3, 0, hue * 3};
            } else {
                hue -= 170;
                color = (RGB_Color){0, hue * 3, 255 - hue * 3};
            }
            WS2812_SetColor(i, color);
        }
    } else {
        uint8_t hue = (beat_counter * 5) % 255;
        RGB_Color color;
        
        if (hue < 85) {
            color = (RGB_Color){hue * 3, 255 - hue * 3, 0};
        } else if (hue < 170) {
            hue -= 85;
            color = (RGB_Color){255 - hue * 3, 0, hue * 3};
        } else {
            hue -= 170;
            color = (RGB_Color){0, hue * 3, 255 - hue * 3};
        }
        WS2812_SetAll(color);
    }
}

// 完全重写的涂鸦模式 - 使用简单的直接颜色映射
// 在Light_GraffitiMode函数中添加强制检查
static void Light_GraffitiMode(void) {
    float distance = Tran_GetDistance();
    
    if (distance == 0.0f) {
        WS2812_SetAll((RGB_Color){255, 0, 0});
        return;
    }
    
    // 简单的直接颜色映射
    RGB_Color color;
    
    if (distance < 15.0f) {
        color = (RGB_Color){255, 0, 0};        // 红色
    } else if (distance < 30.0f) {
        color = (RGB_Color){255, 100, 0};      // 橙色
    } else if (distance < 45.0f) {
        color = (RGB_Color){255, 255, 0};      // 黄色
    } else if (distance < 60.0f) {
        color = (RGB_Color){0, 255, 0};        // 绿色
    } else if (distance < 75.0f) {
        color = (RGB_Color){0, 255, 255};      // 青色
    } else if (distance < 90.0f) {
        color = (RGB_Color){0, 0, 255};        // 蓝色
    } else {
        color = (RGB_Color){255, 0, 255};      // 紫色
    }
    
    // 亮度控制
    uint8_t brightness;
    if (distance < 20.0f) {
        brightness = 255;
    } else if (distance < 50.0f) {
        brightness = 200;
    } else if (distance < 80.0f) {
        brightness = 150;
    } else {
        brightness = 100;
    }
    
    color.r = color.r * brightness / 255;
    color.g = color.g * brightness / 255;
    color.b = color.b * brightness / 255;
    
    WS2812_SetAll(color);
    
    // 强制超时测试：如果超过1000次循环（10秒），强制退出
    static uint32_t force_timeout = 0;
    force_timeout++;
    if (force_timeout > 1000) {
        printf("!!! FORCE TIMEOUT TRIGGERED !!!\n");
        graffiti_active = 0;
        graffiti_timeout = 0;
        force_timeout = 0;
        current_mode = MODE_ENVIRONMENT;
        
        // 强制退出提示
        for(int i = 0; i < 3; i++) {
            WS2812_SetAll((RGB_Color){255, 0, 0});
            WS2812_Update();
            delay_ms(200);
            WS2812_SetAll(COLOR_OFF);
            WS2812_Update();
            delay_ms(200);
        }
    }
}

// 修改进入涂鸦模式函数，重置超时计数器
void Light_EnterGraffitiMode(void) {
    graffiti_active = 1;
    graffiti_timeout = 0;  // 重要：进入时重置超时计数器
    current_mode = MODE_GRAFFITI;
    
    printf("Entering Graffiti mode - Timeout reset to 0\n");
    
    for(int i = 0; i < 3; i++) {
        WS2812_SetAll((RGB_Color){255, 255, 255});
        WS2812_Update();
        delay_ms(100);
        WS2812_SetAll(COLOR_OFF);
        WS2812_Update();
        delay_ms(100);
    }
}

// 修改主更新函数
void Light_UpdateFromEnvironment(int temp, int humi, float air_quality) {
    static uint32_t update_counter = 0;
    update_counter++;
    
    // 每50次更新显示一次
    if (update_counter % 50 == 0) {
        printf("Light_Update called: %lu times\n", update_counter);
    }
    
    light_counter++;
    
    if (graffiti_active) {
        Light_GraffitiMode();
        
        // 超时计数器递增
        graffiti_timeout++;
        
        // 在超时检测部分修改
    if (graffiti_timeout >= 200) {  // 改为200次，对应约6秒
        printf("*** AUTO TIMEOUT TRIGGERED ***\n");
        graffiti_active = 0;
        graffiti_timeout = 0;
        current_mode = MODE_ENVIRONMENT;
            
            // 退出提示
            for(int i = 0; i < 2; i++) {
                WS2812_SetAll((RGB_Color){100, 100, 100});
                WS2812_Update();
                delay_ms(200);
                WS2812_SetAll(COLOR_OFF);
                WS2812_Update();
                delay_ms(200);
            }
            printf("Returned to environment mode\n");
        }
    } else {
        // 正常模式
        switch(current_mode) {
            case MODE_ENVIRONMENT:
                Light_EnvironmentMode(temp, humi, air_quality);
                break;
            case MODE_FOCUS:
                Light_FocusMode();
                break;
            case MODE_RELAX:
                Light_RelaxMode();
                break;
            case MODE_PARTY:
                Light_PartyMode();
                break;
        }
    }
    
    WS2812_Update();
    delay_ms(10); // 确保这是10ms延时
}

// Mode switching
void Light_SetMode(uint8_t mode) {
    current_mode = mode;
    graffiti_active = 0;  // 切换模式时退出涂鸦模式
    
    printf("Light Mode %d\n", mode);
    
    RGB_Color mode_color;
    switch (mode) {
        case MODE_ENVIRONMENT: 
            mode_color = (RGB_Color){150, 150, 150};
            break;
        case MODE_FOCUS: 
            mode_color = (RGB_Color){0, 0, 200};
            break;
        case MODE_RELAX: 
            mode_color = (RGB_Color){200, 100, 0};
            break;
        case MODE_PARTY: 
            mode_color = (RGB_Color){255, 0, 255};
            break;
        default:
            mode_color = (RGB_Color){100, 100, 100};
            break;
    }
    
    WS2812_SetAll(mode_color);
    WS2812_Update();
    delay_ms(300);
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
    delay_ms(100);
}