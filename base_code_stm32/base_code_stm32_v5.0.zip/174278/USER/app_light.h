#ifndef __APP_LIGHT_H
#define __APP_LIGHT_H

#include "ws2812.h"

// 模式定义
#define MODE_ENVIRONMENT 0
#define MODE_FOCUS       1
#define MODE_RELAX       2
#define MODE_PARTY       3  // 新增派对模式
#define MODE_GRAFFITI    4  // 新增光影涂鸦模式

// 外部变量声明
extern uint8_t graffiti_active;
extern uint32_t graffiti_timeout;  // 添加超时计数器声明


void Light_Init(void);
void Light_UpdateFromEnvironment(int temp, int humi, float air_quality);
void Light_SetMode(uint8_t mode);
void Light_DebugTest();
void Light_EnterGraffitiMode(void);  // 新增进入涂鸦模式函数

#endif