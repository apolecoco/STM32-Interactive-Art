/**
  ******************************************************************************
  * @ 名称  STM32 学习模板
  * @ 版本  STD 库 V3.5.0
  * @ 描述  适用于嵌入式虚拟仿真平台
  *         
  * @ 注意  本程序只供学习使用
  ******************************************************************************
  */


#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"
#include "adc.h"
#include "stm32f10x_conf.h"
#include "usart.h"
#include "key.h"
#include "Tran.h"
// 包含我们新创建的应用显示模块
#include "app_display.h" 
#include "app_light.h"


int main(void) {

#if 1
    // 系统初始化
    ADC1_DMA_Config();
    AppDisplay_Init();
    Light_Init();
    uart_init(115200);
    KEY_Init();
    // 启动时显示模式提示
    Tran_Init();  // 初始化超声波（不影响现有功能）

    
    printf("All modules initialized - Graffiti mode ready\n");
    
    uint32_t main_counter = 0;    

    while (1) {
        main_counter++;
        
        // 手势检测
        if (!graffiti_active && Tran_DetectHandWave()) {
            printf("Hand wave - Entering Graffiti mode\n");
            Light_EnterGraffitiMode();
        }
        
        // Check all keys
        Key_Press_t key = KEY_Check();
        if (key != KEY_NONE) {
            switch(key) {
                case KEY_MODE_FOCUS:
                    printf("Switch to FOCUS mode\r\n");
                    Light_SetMode(MODE_FOCUS);
                    break;
                case KEY_MODE_RELAX:
                    printf("Switch to RELAX mode\r\n");
                    Light_SetMode(MODE_RELAX);
                    break;
                case KEY_MODE_ENV:
                    printf("Switch to ENVIRONMENT mode\r\n");
                    Light_SetMode(MODE_ENVIRONMENT);
                    break;
                case KEY_MODE_PARTY:
                    printf("Switch to PARTY mode\r\n");
                    Light_SetMode(MODE_PARTY);
                    break;
                default:
                    break; // 处理KEY_NONE
            }
        }
        
        // 保持环境功能
        AppDisplay_Update();
        int temp = GetCurrentTemperature();
        int humi = GetCurrentHumidity();
        float air = GetCurrentAirQuality();
        Light_UpdateFromEnvironment(temp, humi, air);
        
        // 超声波显示（简化）
        static uint32_t sensor_counter = 0;
        if (sensor_counter % 50 == 0 && graffiti_active) {
            float distance = Tran_GetDistance();
            if (distance > 0) {
                printf("Graffiti - Distance: %.1f cm, Timeout: %lu/600 (%.1f seconds)\n", 
               distance, graffiti_timeout, (float)graffiti_timeout/100.0f);
            }
        }
        sensor_counter++;

        delay_ms(10);
    }

#else

// 只初始化最基础的功能
    uart_init(115200);
    printf("=== MINIMAL GRAFFITI TEST ===\n");
    
    // 只初始化必要的模块
    Light_Init();
    KEY_Init();
    Tran_Init();
    
    printf("Minimal system ready\n");
    printf("Testing graffiti mode with direct update\n");
    
    uint32_t main_counter = 0;
    uint32_t graffiti_enter_time = 0;
    uint8_t graffiti_entered = 0;
    
    while (1) {
        main_counter++;
        
        // 每100次循环显示状态
        if (main_counter % 100 == 0) {
            printf("Main loop: %lu, Graffiti: %d\n", main_counter, graffiti_active);
        }
        
        // 手势检测进入涂鸦模式
        if (!graffiti_active && Tran_DetectHandWave()) {
            printf("=== ENTERING GRAFFITI MODE ===\n");
            Light_EnterGraffitiMode();
            graffiti_enter_time = main_counter;
            graffiti_entered = 1;
        }
        
        // 如果进入了涂鸦模式，直接调用更新函数
        if (graffiti_active) {
            // 模拟环境数据（避免传感器读取阻塞）
            int temp = 250;
            int humi = 500;
            float air = 1.5f;
            
            // 直接调用灯光更新
            Light_UpdateFromEnvironment(temp, humi, air);
            
            // 显示超时状态
            if (main_counter % 50 == 0) {
                printf("Graffiti timeout: %lu/800\n", graffiti_timeout);
            }
            
            // 手动超时检查（10秒）
            if (main_counter - graffiti_enter_time > 1000) {
                printf("!!! MANUAL TIMEOUT AFTER 10 SECONDS !!!\n");
                graffiti_active = 0;
                graffiti_timeout = 0;
                printf("Exited graffiti mode\n");
            }
        }
        
        // 按键检测（简化版）
        Key_Press_t key = KEY_Check();
        if (key != KEY_NONE && graffiti_active) {
            printf("Key pressed, exiting graffiti\n");
            graffiti_active = 0;
            Light_SetMode(key); // 切换到按键对应的模式
        }
        
        // 超声波显示
        static uint32_t sensor_counter = 0;
        if (sensor_counter % 30 == 0) {
            float distance = Tran_GetDistance();
            if (distance > 0) {
                printf("Distance: %.1f cm", distance);
                if (graffiti_active) {
                    printf(" [GRAFFITI MODE]");
                }
                printf("\n");
            }
        }
        sensor_counter++;
        
        delay_ms(10);
    }
#endif
}

