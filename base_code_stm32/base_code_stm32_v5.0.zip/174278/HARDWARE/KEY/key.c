#include "key.h"
#include "delay.h"
#include "usart.h"

// 按键状态变量
static uint8_t last_focus_state = 0;
static uint8_t last_relax_state = 0;
static uint8_t last_env_state = 0;
static uint8_t last_party_state = 0; // 新增派对按键状态

void KEY_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // 使能GPIOA和GPIOB时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
    
    // 配置PA6, PA7, PA8为下拉输入
    GPIO_InitStructure.GPIO_Pin = KEY_FOCUS_PIN | KEY_RELAX_PIN | KEY_ENV_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(KEY_PORT, &GPIO_InitStructure);
    
    // 配置PB9为下拉输入（派对按键）
    GPIO_InitStructure.GPIO_Pin = KEY_PARTY_PIN;
    GPIO_Init(KEY_PARTY_PORT, &GPIO_InitStructure);
    
    printf("=== Key Driver Initialized ===\r\n");
    printf("PA6:Focus PA7:Relax PA8:Env PB9:Party\r\n");
    printf("All keys: Normal=LOW, Pressed=HIGH (VCC Connection)\r\n");
}

Key_Press_t KEY_Check(void) {
    uint8_t current_focus = GPIO_ReadInputDataBit(KEY_PORT, KEY_FOCUS_PIN);
    uint8_t current_relax = GPIO_ReadInputDataBit(KEY_PORT, KEY_RELAX_PIN);
    uint8_t current_env = GPIO_ReadInputDataBit(KEY_PORT, KEY_ENV_PIN);
    uint8_t current_party = GPIO_ReadInputDataBit(KEY_PARTY_PORT, KEY_PARTY_PIN);
    
    // 检测Focus键按下 (PA6)
    if (last_focus_state == 0 && current_focus == 1) {
        last_focus_state = current_focus;
        delay_ms(5);
        if (GPIO_ReadInputDataBit(KEY_PORT, KEY_FOCUS_PIN) == 1) {
            printf("Key Press: FOCUS MODE (PA6)\r\n");
            return KEY_MODE_FOCUS;
        }
    }
    last_focus_state = current_focus;
    
    // 检测Relax键按下 (PA7)
    if (last_relax_state == 0 && current_relax == 1) {
        last_relax_state = current_relax;
        delay_ms(5);
        if (GPIO_ReadInputDataBit(KEY_PORT, KEY_RELAX_PIN) == 1) {
            printf("Key Press: RELAX MODE (PA7)\r\n");
            return KEY_MODE_RELAX;
        }
    }
    last_relax_state = current_relax;
    
    // 检测Env键按下 (PA8)
    if (last_env_state == 0 && current_env == 1) {
        last_env_state = current_env;
        delay_ms(5);
        if (GPIO_ReadInputDataBit(KEY_PORT, KEY_ENV_PIN) == 1) {
            printf("Key Press: ENVIRONMENT MODE (PA8)\r\n");
            return KEY_MODE_ENV;
        }
    }
    last_env_state = current_env;
    
    // 检测Party键按下 (PB9)
    if (last_party_state == 0 && current_party == 1) {
        last_party_state = current_party;
        delay_ms(5);
        if (GPIO_ReadInputDataBit(KEY_PARTY_PORT, KEY_PARTY_PIN) == 1) {
            printf("Key Press: PARTY MODE (PB9)\r\n");
            return KEY_MODE_PARTY;
        }
    }
    last_party_state = current_party;
    
    return KEY_NONE;
}