#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x.h"
#include "sys.h"

// 按键引脚定义
#define KEY_FOCUS_PIN    GPIO_Pin_6   // PA6 - Focus Mode
#define KEY_RELAX_PIN    GPIO_Pin_7   // PA7 - Relax Mode  
#define KEY_ENV_PIN      GPIO_Pin_8   // PA8 - Environment Mode
#define KEY_PARTY_PIN    GPIO_Pin_9   // PB9 - Party Mode (新增)
#define KEY_PORT         GPIOA
#define KEY_PARTY_PORT   GPIOB       // 派对按键使用GPIOB

// 按键模式枚举
typedef enum {
    KEY_NONE = 0,
    KEY_MODE_FOCUS,     // Focus Mode
    KEY_MODE_RELAX,     // Relax Mode
    KEY_MODE_ENV,       // Environment Mode
    KEY_MODE_PARTY      // Party Mode (新增)
} Key_Press_t;

// 函数声明
void KEY_Init(void);
Key_Press_t KEY_Check(void);
void KEY_DebugTest(void);

#endif