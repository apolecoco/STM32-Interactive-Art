#include "ws2812.h"
#include "delay.h"

// WS2812数据缓冲区 (每个灯珠需要24bit = 3字节)
static uint8_t ws2812_buffer[LED_NUM * 3];

// 初始化GPIO
void WS2812_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // 修改为 GPIOB 时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  // 改为 GPIOB
    
    GPIO_InitStructure.GPIO_Pin = LED_PIN;              // 改为 Pin_8
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);                // 改为 GPIOB
    
    GPIO_SetBits(GPIOB, GPIO_Pin_8);                      // 改为 GPIOB, Pin_8
    
    WS2812_Clear();
}

// 蓝色通道修复函数
static RGB_Color FixBlueChannel(RGB_Color original_color) {
    // 检测是否是纯蓝色情况
    if (original_color.g == 0 && original_color.r == 0 && original_color.b > 0) {
        // 纯蓝色时，轻微激活绿色通道来抑制红色通道
        return (RGB_Color){10, 0, original_color.b};  // G=10, R=0, B=原值
    }
    // 其他颜色保持不变
    return original_color;
}

// 修正为RGB顺序
void WS2812_SetColor(uint8_t index, RGB_Color color) {
    if (index >= LED_NUM) return;
    
    uint8_t *p = &ws2812_buffer[index * 3];
    p[0] = color.r;  // R - 原来是G
    p[1] = color.g;  // G - 原来是R  
    p[2] = color.b;  // B - 不变
}


// 修正SetAll函数
void WS2812_SetAll(RGB_Color color) {
    for (uint8_t i = 0; i < LED_NUM; i++) {
        uint8_t *p = &ws2812_buffer[i * 3];
        p[0] = color.r;  // R
        p[1] = color.g;  // G
        p[2] = color.b;  // B
    }
}
// 清空所有灯珠
void WS2812_Clear(void) {
    for (uint8_t i = 0; i < sizeof(ws2812_buffer); i++) {
        ws2812_buffer[i] = 0;
    }
}

// 更稳定的延时函数
static void WS2812_Delay(uint32_t cycles) {
    volatile uint32_t i = cycles;
    while(i--) {
        __asm__("nop");  // 插入空指令，增加稳定性
    }
}
// 重写发送函数，增加时序容错
static void WS2812_SendByte(uint8_t byte) {
    for (int8_t bit = 7; bit >= 0; bit--) {
        if (byte & (1 << bit)) {
            // 发送'1': 稍微延长高电平时间
            GPIO_SetBits(LED_PORT, LED_PIN);
            WS2812_Delay(25);  // 增加延时
            GPIO_ResetBits(LED_PORT, LED_PIN);
            WS2812_Delay(9);   // 减少低电平时间
        } else {
            // 发送'0': 保持较短高电平
            GPIO_SetBits(LED_PORT, LED_PIN);
            WS2812_Delay(9);   // 较短高电平
            GPIO_ResetBits(LED_PORT, LED_PIN);
            WS2812_Delay(25);  // 较长低电平
        }
    }
}

// 增加复位时间
void WS2812_Update(void) {
    __disable_irq();  // 禁用中断
    
    // 发送数据前先确保低电平
    GPIO_ResetBits(LED_PORT, LED_PIN);
    WS2812_Delay(100);
    
    for (uint16_t i = 0; i < sizeof(ws2812_buffer); i++) {
        WS2812_SendByte(ws2812_buffer[i]);
    }
    
    // 延长复位信号
    GPIO_ResetBits(LED_PORT, LED_PIN);
    WS2812_Delay(1500);  // 显著增加复位时间
    
    __enable_irq();
}

// 测试模式：显示彩虹色
void WS2812_TestPattern(void) {
    RGB_Color test_colors[8] = {
        COLOR_RED, COLOR_GREEN, COLOR_BLUE,
        COLOR_YELLOW, COLOR_CYAN, COLOR_MAGENTA,
        COLOR_WHITE, COLOR_OFF
    };
    
    for (uint8_t i = 0; i < LED_NUM; i++) {
        WS2812_SetColor(i, test_colors[i]);
    }
}

// 逐步测试函数 - 新增的调试函数
void WS2812_DebugTest(void) {
    // 测试1: 只点亮第一个灯珠红色
    WS2812_SetColor(0, COLOR_RED);
    WS2812_SetColor(1, COLOR_OFF);
    WS2812_SetColor(2, COLOR_OFF);
    WS2812_SetColor(3, COLOR_OFF);
    WS2812_SetColor(4, COLOR_OFF);
    WS2812_SetColor(5, COLOR_OFF);
    WS2812_SetColor(6, COLOR_OFF);
    WS2812_SetColor(7, COLOR_OFF);
    WS2812_Update();
    delay_ms(2000);
    
    // 测试2: 只点亮第二个灯珠绿色
    WS2812_SetColor(0, COLOR_OFF);
    WS2812_SetColor(1, COLOR_GREEN);
    WS2812_Update();
    delay_ms(2000);
    
    // 测试3: 所有灯珠蓝色
    WS2812_SetAll(COLOR_BLUE);
    WS2812_Update();
    delay_ms(2000);
    
    // 测试4: 彩虹测试
    WS2812_TestPattern();
    WS2812_Update();
    delay_ms(2000);
    
    // 测试5: 全部关闭
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
    delay_ms(1000);
}
// 测试不同的颜色顺序
void WS2812_ColorOrderTest(void) {
    // 测试1: 纯红色 (尝试不同编码)
    //printf("Testing RED - GRB order\n");
    WS2812_SetAll((RGB_Color){0, 255, 0});  // GRB: 红色
    WS2812_Update();
    delay_ms(2000);
    
    // 测试2: 纯绿色
    //printf("Testing GREEN - GRB order\n");
    WS2812_SetAll((RGB_Color){255, 0, 0});  // GRB: 绿色
    WS2812_Update();
    delay_ms(2000);
    
    // 测试3: 纯蓝色
    //printf("Testing BLUE - GRB order\n");
    WS2812_SetAll((RGB_Color){0, 0, 255});  // GRB: 蓝色
    WS2812_Update();
    delay_ms(2000);
    
    // 测试4: 尝试RGB顺序
    //printf("Testing RGB order\n");
    WS2812_SetAll((RGB_Color){255, 0, 0});  // 如果是RGB顺序，这应该是红色
    WS2812_Update();
    delay_ms(2000);
    
    WS2812_SetAll((RGB_Color){0, 255, 0});  // 如果是RGB顺序，这应该是绿色
    WS2812_Update();
    delay_ms(2000);
    
    // 全部关闭
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}

// 稳定性测试 - 重复发送相同颜色
void WS2812_StabilityTest(void) {
    for (int repeat = 0; repeat < 10; repeat++) {
        // 测试1: 所有灯珠红色
        WS2812_SetAll((RGB_Color){0, 255, 0});  // GRB: 红色
        WS2812_Update();
        delay_ms(500);
        
        // 测试2: 所有灯珠绿色  
        WS2812_SetAll((RGB_Color){255, 0, 0});  // GRB: 绿色
        WS2812_Update();
        delay_ms(500);
        
        // 测试3: 所有灯珠蓝色
        WS2812_SetAll((RGB_Color){0, 0, 255});  // GRB: 蓝色
        WS2812_Update();
        delay_ms(500);
    }
    
    // 最后关闭
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}

// 简单可靠的颜色映射（基于你的观察）
void WS2812_ReliableColors(void) {
    // 使用我们观察到的可靠颜色组合
    RGB_Color reliable_red = {0, 200, 0};     // GRB
    RGB_Color reliable_green = {200, 0, 0};   // GRB  
    RGB_Color reliable_blue = {0, 0, 200};    // GRB
    
    // 分别点亮不同颜色的灯珠
    WS2812_SetColor(0, reliable_red);
    WS2812_SetColor(1, reliable_green);
    WS2812_SetColor(2, reliable_blue);
    WS2812_SetColor(3, reliable_red);
    WS2812_SetColor(4, reliable_green);
    WS2812_SetColor(5, reliable_blue);
    WS2812_SetColor(6, reliable_red);
    WS2812_SetColor(7, reliable_green);
    
    WS2812_Update();
    delay_ms(3000);
    
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}


// 在ws2812.c中添加
void WS2812_FindColorOrder(void) {
    // 测试不同的颜色顺序
    printf("=== Finding Correct Color Order ===\r\n");
    
    // 测试1: GRB顺序 (我们的假设)
    printf("Testing GRB Order (our assumption)\r\n");
    WS2812_SetAll((RGB_Color){0, 255, 0});   // GRB: 红色
    WS2812_Update();
    delay_ms(3000);
    
    // 测试2: RGB顺序
    printf("Testing RGB Order\r\n"); 
    for(int i=0; i<LED_NUM; i++) {
        ws2812_buffer[i*3 + 0] = 255;  // R
        ws2812_buffer[i*3 + 1] = 0;    // G
        ws2812_buffer[i*3 + 2] = 0;    // B
    }
    WS2812_Update();
    delay_ms(3000);
    
    // 测试3: BRG顺序
    printf("Testing BRG Order\r\n");
    for(int i=0; i<LED_NUM; i++) {
        ws2812_buffer[i*3 + 0] = 0;    // B
        ws2812_buffer[i*3 + 1] = 255;  // R
        ws2812_buffer[i*3 + 2] = 0;    // G
    }
    WS2812_Update();
    delay_ms(3000);
    
    // 关闭
    WS2812_SetAll(COLOR_OFF);
    WS2812_Update();
}

void WS2812_DirectBufferTest(void) {
    printf("=== Direct Buffer Test ===\r\n");
    
    // 完全绕过SetColor函数，直接操作缓冲区
    // 测试纯红色 (RGB顺序)
    printf("Direct RED (RGB)\r\n");
    for(int i=0; i<LED_NUM; i++) {
        ws2812_buffer[i*3 + 0] = 255;  // R
        ws2812_buffer[i*3 + 1] = 0;    // G  
        ws2812_buffer[i*3 + 2] = 0;    // B
    }
    WS2812_Update();
    delay_ms(3000);
    
    // 测试纯绿色 (RGB顺序)
    printf("Direct GREEN (RGB)\r\n");
    for(int i=0; i<LED_NUM; i++) {
        ws2812_buffer[i*3 + 0] = 0;    // R
        ws2812_buffer[i*3 + 1] = 255;  // G
        ws2812_buffer[i*3 + 2] = 0;    // B
    }
    WS2812_Update();
    delay_ms(3000);
    
    // 测试纯蓝色 (RGB顺序)  
    printf("Direct BLUE (RGB)\r\n");
    for(int i=0; i<LED_NUM; i++) {
        ws2812_buffer[i*3 + 0] = 0;    // R
        ws2812_buffer[i*3 + 1] = 0;    // G
        ws2812_buffer[i*3 + 2] = 255;  // B
    }
    WS2812_Update();
    delay_ms(3000);
    
    WS2812_Clear();
    WS2812_Update();
}
