#ifndef __WS2812_H
#define __WS2812_H

#include "sys.h"
#include "stm32f10x.h"
#include "usart.h"

// 配置
#define LED_NUM 8                    // 8个灯珠
// 修改这两行
#define LED_PIN GPIO_Pin_8          // 从 PA10 改为 PB8
#define LED_PORT GPIOB              // 从 GPIOA 改为 GPIOB


// RGB颜色结构体 (WS2812需要GRB顺序)
typedef struct {
    uint8_t g;  // 绿色
    uint8_t r;  // 红色  
    uint8_t b;  // 蓝色
} RGB_Color;

// 函数声明
void WS2812_Init(void);
void WS2812_SetColor(uint8_t index, RGB_Color color);
void WS2812_SetAll(RGB_Color color);
void WS2812_Update(void);
void WS2812_Clear(void);
void WS2812_TestPattern(void);
//测试函数
void WS2812_DebugTest(void);  // 添加这行
void WS2812_ColorOrderTest(void);
void WS2812_StabilityTest(void);
void WS2812_ReliableColors(void);
void WS2812_TestBlueFix(void);  // 蓝色通道修复测试
void WS2812_FindColorOrder(void);
void WS2812_DirectBufferTest(void);

// 修正为RGB顺序
#define COLOR_RED       ((RGB_Color){255, 0, 0})      // RGB: 红色
#define COLOR_GREEN     ((RGB_Color){0, 255, 0})      // RGB: 绿色  
#define COLOR_BLUE      ((RGB_Color){0, 0, 255})      // RGB: 蓝色
#define COLOR_YELLOW    ((RGB_Color){255, 255, 0})    // RGB: 黄色
#define COLOR_CYAN      ((RGB_Color){0, 255, 255})    // RGB: 青色
#define COLOR_MAGENTA   ((RGB_Color){255, 0, 255})    // RGB: 洋红
#define COLOR_WHITE     ((RGB_Color){255, 255, 255})  // RGB: 白色
#define COLOR_OFF       ((RGB_Color){0, 0, 0})        // RGB: 关闭

#endif