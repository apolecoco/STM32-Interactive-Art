#ifndef __TRAN_H
#define __TRAN_H

#include "stm32f10x.h"
#include "sys.h"

// 超声波引脚定义
#define TRIG_PIN    GPIO_Pin_1    // PA1 - Trig
#define ECHO_PIN    GPIO_Pin_2    // PA2 - Echo
#define TRANS_PORT  GPIOA

// 函数声明
void Tran_Init(void);
float Tran_GetDistance(void);
uint8_t Tran_DetectHandWave(void);
void Tran_DebugTest(void);

#endif