#include "Tran.h"
#include "delay.h"
#include "usart.h"

void Tran_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // 确保GPIOA时钟使能
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // 配置Trig引脚 (PA1) 为推挽输出
    GPIO_InitStructure.GPIO_Pin = TRIG_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(TRANS_PORT, &GPIO_InitStructure);
    
    // 配置Echo引脚 (PA2) 为浮空输入
    GPIO_InitStructure.GPIO_Pin = ECHO_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(TRANS_PORT, &GPIO_InitStructure);
    
    // 初始化为低电平
    GPIO_ResetBits(TRANS_PORT, TRIG_PIN);
    
    printf("Ultrasonic integrated successfully\n");
}

float Tran_GetDistance(void) {
    uint32_t timeout = 0;
    uint32_t high_time = 0;
    
    // 发送触发脉冲
    GPIO_ResetBits(TRANS_PORT, TRIG_PIN);
    delay_us(2);
    GPIO_SetBits(TRANS_PORT, TRIG_PIN);
    delay_us(15);
    GPIO_ResetBits(TRANS_PORT, TRIG_PIN);
    
    // 等待回波开始
    timeout = 0;
    while (GPIO_ReadInputDataBit(TRANS_PORT, ECHO_PIN) == 0) {
        if (timeout++ > 10000) {
            return 0.0;
        }
        delay_us(1);
    }
    
    // 测量高电平时间
    high_time = 0;
    while (GPIO_ReadInputDataBit(TRANS_PORT, ECHO_PIN) == 1) {
        high_time++;
        delay_us(1);
        if (high_time > 25000) {
            break;
        }
    }
    
    if (high_time == 0) {
        return 0.0;
    }
    
    // 计算距离
    float distance = high_time * 0.0343f / 2.0f;
    
    // 限制有效范围
    if (distance > 400.0f) distance = 400.0f;
    if (distance < 2.0f) distance = 2.0f;
    
    return distance;
}

uint8_t Tran_DetectHandWave(void) {
    static float last_distance = 0;
    
    float current_distance = Tran_GetDistance();
    if (current_distance == 0.0f) return 0;
    
    // 检测距离突变
    if (last_distance > 0) {
        float distance_change = (current_distance > last_distance) ? 
                               (current_distance - last_distance) : 
                               (last_distance - current_distance);
        
        if (distance_change > 15.0f) {
            last_distance = current_distance;
            printf("Hand wave detected Change %.1f cm\n", distance_change);
            return 1;
        }
    }
    
    last_distance = current_distance;
    return 0;
}

void Tran_DebugTest(void) {
    printf("Ultrasonic debug test\n");
    
    while(1) {
        float dist = Tran_GetDistance();
        if (dist > 0) {
            printf("Distance %.1f cm\n", dist);
        }
        delay_ms(300);
    }
}