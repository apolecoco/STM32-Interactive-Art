#ifndef __DHT11_H
#define __DHT11_H 
#include "sys.h"   


void PT8211_Init(void);
void PT8211_Output(int16_t right_ch, int16_t lift_ch);


#endif















