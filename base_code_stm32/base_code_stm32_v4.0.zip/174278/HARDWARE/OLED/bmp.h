#ifndef __BMP_H
#define __BMP_H

extern unsigned char BMP1[];

extern unsigned char BMP2[] ;

//*"龙.bmp",0*/
extern unsigned char BMP_LONG[];

/*"国旗.bmp",0*/
extern unsigned char BMP_GUOQI[];

#endif
