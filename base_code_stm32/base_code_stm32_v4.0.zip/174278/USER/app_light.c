#include "app_light.h"
#include "delay.h"
#include "usart.h"
#include <math.h>

static uint32_t light_counter = 0;
static uint8_t current_mode = MODE_ENVIRONMENT;

void Light_Init(void) {
    WS2812_Init();
}

// 在文件顶部添加派对模式相关函数
static uint16_t simulate_audio_input(void) {
    static uint32_t counter = 0;
    counter++;
    
    // 模式1: 随机噪声 (模拟环境嘈杂度)
    // return rand() % 256;
    
    // 模式2: 节拍器 (模拟音乐节奏，用于派对模式)
    return (sin(counter * 0.2) + 1) * 128; // 生成0-255之间的正弦波
}

// HSV到RGB转换函数
static RGB_Color hue_to_color(uint8_t hue) {
    RGB_Color color;
    
    if (hue < 85) {
        color.r = hue * 3;
        color.g = 255 - hue * 3;
        color.b = 0;
    } else if (hue < 170) {
        hue -= 85;
        color.r = 255 - hue * 3;
        color.g = 0;
        color.b = hue * 3;
    } else {
        hue -= 170;
        color.r = 0;
        color.g = hue * 3;
        color.b = 255 - hue * 3;
    }
    
    return color;
}


static RGB_Color MapTemperatureToColor(int temperature) {
    if (temperature < 200) {
        return (RGB_Color){0, 0, 255};
    } else if (temperature < 250) {
        return (RGB_Color){0, 255, 0};
    } else if (temperature < 280) {
        return (RGB_Color){255, 255, 0};
    } else {
        return (RGB_Color){255, 0, 0};
    }
}

// 派对模式 - 声音可视化效果
static void Light_PartyMode(void) {
    static uint32_t beat_counter = 0;
    beat_counter++;
    
    // 模拟音频输入
    uint16_t audio_level = simulate_audio_input();
    
    // 根据音频强度控制灯光效果
    if (audio_level > 200) {
        // 强节奏：快速闪烁彩虹色
        for (int i = 0; i < LED_NUM; i++) {
            uint8_t hue = (beat_counter * 20 + i * 32) % 255;
            RGB_Color color = hue_to_color(hue);
            WS2812_SetColor(i, color);
        }
    } else if (audio_level > 150) {
        // 中等节奏：呼吸式颜色变化
        uint8_t breath = (beat_counter % 30) < 15 ? 
                        (beat_counter % 30) * 17 : 
                        (30 - (beat_counter % 30)) * 17;
        
        RGB_Color breath_color = {breath, 0, 255 - breath}; // 蓝紫渐变
        WS2812_SetAll(breath_color);
    } else {
        // 弱节奏：缓慢颜色流动
        uint8_t base_hue = (beat_counter / 3) % 255;
        for (int i = 0; i < LED_NUM; i++) {
            uint8_t hue = (base_hue + i * 20) % 255;
            RGB_Color color = hue_to_color(hue);
            WS2812_SetColor(i, color);
        }
    }
}

static void Light_FocusMode(void) {
    // 极速呼吸：15次计数完成一次呼吸
    uint8_t phase = light_counter % 15;  // 改小这个数字
    
    uint8_t brightness;
    
    if (phase < 8) {
        brightness = phase * 30;  // 改大这个数字，让变化更陡峭
    } else {
        brightness = (15 - phase) * 30;  // 同步修改
    }
    
    RGB_Color focus_color = {0, 0, brightness};
    WS2812_SetAll(focus_color);
}

// 放松模式 - 超快流动效果
static void Light_RelaxMode(void) {
    // 超快流动：每个灯珠有明显的跑马灯效果
    uint8_t base_pos = light_counter % LED_NUM; // 更快的流动
    
    for (int i = 0; i < LED_NUM; i++) {
        uint8_t pos = (base_pos + i) % LED_NUM;
        uint8_t brightness = (pos < 4) ? 255 : 0; // 4个灯珠亮，4个灭
        
        RGB_Color relax_color = {brightness, brightness / 2, 0};
        WS2812_SetColor(i, relax_color);
    }
}

// 放松模式备选方案 - 超快彩虹流动
static void Light_RelaxMode_Rainbow(void) {
    for (int i = 0; i < LED_NUM; i++) {
        uint8_t hue = (light_counter * 10 + i * 40) % 255; // 更快的颜色变化
        
        RGB_Color color;
        if (hue < 85) {
            color = (RGB_Color){hue * 3, 255 - hue * 3, 0};
        } else if (hue < 170) {
            hue -= 85;
            color = (RGB_Color){255 - hue * 3, 0, hue * 3};
        } else {
            hue -= 170;
            color = (RGB_Color){0, hue * 3, 255 - hue * 3};
        }
        
        WS2812_SetColor(i, color);
    }
}

// 环境模式
static void Light_EnvironmentMode(int temp, int humi, float air_quality) {
    RGB_Color base_color = MapTemperatureToColor(temp);
    
    if (air_quality > 1.8) {
        // 超快闪烁警示 (4Hz)
        if (light_counter % 3 == 0) {
            WS2812_SetAll((RGB_Color){255, 0, 0});
        } else {
            WS2812_SetAll(COLOR_OFF);
        }
    } else {
        WS2812_SetAll(base_color);
    }
}

// 在 Light_UpdateFromEnvironment 函数中添加派对模式
void Light_UpdateFromEnvironment(int temp, int humi, float air_quality) {
    light_counter++;
    
    switch(current_mode) {
        case MODE_ENVIRONMENT:
            Light_EnvironmentMode(temp, humi, air_quality);
            break;
        case MODE_FOCUS:
            Light_FocusMode();
            break;
        case MODE_RELAX:
            Light_RelaxMode();
            break;
        case MODE_PARTY:  // 新增派对模式
            Light_PartyMode();
            break;
    }
    
    WS2812_Update();
    delay_ms(5);
}

// 在 Light_SetMode 函数中添加派对模式确认效果
void Light_SetMode(uint8_t mode) {
    current_mode = mode;
    light_counter = 0;
    
    printf("Mode: %d\r\n", mode);
    
    RGB_Color mode_color;
    switch (mode) {
        case MODE_ENVIRONMENT: 
            mode_color = (RGB_Color){150, 150, 150};
            break;
        case MODE_FOCUS: 
            mode_color = (RGB_Color){0, 0, 200};
            break;
        case MODE_RELAX: 
            mode_color = (RGB_Color){200, 100, 0};
            break;
        case MODE_PARTY:  // 新增派对模式确认
            mode_color = (RGB_Color){255, 0, 255}; // 洋红色确认
            break;
    }
    
    WS2812_SetAll(mode_color);
    WS2812_Update();
    delay_ms(200);
}