#ifndef __APP_DISPLAY_H
#define __APP_DISPLAY_H

#include "stm32f10x.h"

void AppDisplay_Init(void);
void AppDisplay_Update(void);

// 传感器数据获取函数
int GetCurrentTemperature(void);
int GetCurrentHumidity(void);
float GetCurrentAirQuality(void);

#endif