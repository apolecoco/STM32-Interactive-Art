#include "app_display.h"
#include "iic_oled.h"
#include "led.h"
#include "dht11.h"
#include "MQ_Sensor.h"  // 新增MQ传感器头文件
#include "delay.h"
#include <stdio.h>

// 添加这行：声明外部ADC DMA缓冲区变量
extern volatile unsigned short int ADC_ConvertedValue[5];

// 全局变量定义
int current_temp = 0;
int current_humi = 0;
float current_air = 0.0;

// 获取函数实现
int GetCurrentTemperature(void) {
    return current_temp;
}

int GetCurrentHumidity(void) {
    return current_humi;
}

float GetCurrentAirQuality(void) {
    return current_air;
}

static int display_count = 0;


void AppDisplay_Init(void) {
    LED_Init();
    IIC_OLED_Init();
    
    // 初始化DHT11并检查是否存在
    if (DHT11_Init() == 0) {
        IIC_OLED_Clear();
        IIC_OLED_ShowString(0, 0, "Sensors Ready!");
    } else {
        IIC_OLED_Clear();
        IIC_OLED_ShowString(0, 0, "DHT11 Error!");
    }
    delay_ms(1000);
    IIC_OLED_Clear();
}

// 修改 AppDisplay_Update 函数，确保正确更新全局变量
void AppDisplay_Update(void) {
    char disp_str[24];
    static uint8_t display_page = 0;
    
    // LED闪烁指示系统运行
    GPIO_WriteBit(GPIOC, GPIO_Pin_13, (BitAction)(1 - GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13)));
    
    // 读取传感器数据到局部变量
    int local_temp, local_humi;
    float local_air;
    
    uint8_t dht11_result = DHT11_Read_Data(&local_temp, &local_humi);
    u16 raw_adc = ADC_ConvertedValue[4];
    local_air = (float)raw_adc * 3.3f / 4095.0f;
    
    printf("Sensors - T:%d, H:%d, A:%.2f\r\n", local_temp, local_humi, local_air);
    
    // 重要：更新全局变量
    current_temp = local_temp;
    current_humi = local_humi;
    current_air = local_air;
    
    printf("Globals - T:%d, H:%d, A:%.2f\r\n", current_temp, current_humi, current_air);
    
    // 显示逻辑保持不变...
    if (display_count % 4 == 0) {
        display_page = (display_page + 1) % 4;
    }
    
    IIC_OLED_Clear();
    
    switch (display_page) {
        case 0: // 环境数据屏
            IIC_OLED_ShowString(0, 0, "== Environment ==");
            if (dht11_result == 0) {
                sprintf(disp_str, "Temp: %d.%dC", local_temp/10, abs(local_temp%10));
                IIC_OLED_ShowString(0, 2, disp_str);
                sprintf(disp_str, "Humi: %d.%d%%", local_humi/10, local_humi%10);
                IIC_OLED_ShowString(0, 4, disp_str);
            } else {
                IIC_OLED_ShowString(0, 2, "Sensor Reading...");
            }
            break;
            
        case 1: // 空气质量屏
            IIC_OLED_ShowString(0, 0, "== Air Quality ==");
            sprintf(disp_str, "Voltage: %.2fV", local_air);
            IIC_OLED_ShowString(0, 2, disp_str);
            
            if (local_air < 1.2) {
                IIC_OLED_ShowString(0, 4, "Status: Excellent");
            } else if (local_air < 1.6) {
                IIC_OLED_ShowString(0, 4, "Status: Good");
            } else if (local_air < 2.0) {
                IIC_OLED_ShowString(0, 4, "Status: Moderate");
            } else {
                IIC_OLED_ShowString(0, 4, "Status: Poor!");
            }
            break;
            
        case 2: // 系统状态屏
            IIC_OLED_ShowString(0, 0, "== System Info ==");
            sprintf(disp_str, "ADC Raw: %d", raw_adc);
            IIC_OLED_ShowString(0, 2, disp_str);
            sprintf(disp_str, "Run Time: %d", display_count);
            IIC_OLED_ShowString(0, 4, disp_str);
            IIC_OLED_ShowString(0, 6, "Light Shadow v1.0");
            break;
            
        case 3: // 调试信息屏
            IIC_OLED_ShowString(0, 0, "== Debug Info ==");
            sprintf(disp_str, "G_Temp: %d", current_temp);
            IIC_OLED_ShowString(0, 2, disp_str);
            sprintf(disp_str, "L_Temp: %d", local_temp);
            IIC_OLED_ShowString(0, 4, disp_str);
            sprintf(disp_str, "Getters Work!");
            IIC_OLED_ShowString(0, 6, disp_str);
            break;
    }
    
    display_count++;
    delay_ms(2000);
}