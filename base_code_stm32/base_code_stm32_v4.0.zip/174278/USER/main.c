/**
  ******************************************************************************
  * @ 名称  STM32 学习模板
  * @ 版本  STD 库 V3.5.0
  * @ 描述  适用于嵌入式虚拟仿真平台
  *         
  * @ 注意  本程序只供学习使用
  ******************************************************************************
  */


#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"
#include "adc.h"
#include "stm32f10x_conf.h"
#include "usart.h"
#include "key.h"
// 包含我们新创建的应用显示模块
#include "app_display.h" 
#include "app_light.h"




int main(void) {
    // 系统初始化
    ADC1_DMA_Config();
    AppDisplay_Init();
    Light_Init();
    uart_init(115200);
    KEY_Init();
    // 启动时显示模式提示


    
    printf("=== Light Shadow - Key Test ===\r\n");
    printf("PA6:Focus PA7:Relax PA8:Env PB9:Party\r\n");
    printf("Waiting for key input...\r\n");
    
    while (1) {
        // Check all keys
        Key_Press_t key = KEY_Check();
        if (key != KEY_NONE) {
            switch(key) {
                case KEY_MODE_FOCUS:
                    printf("Switch to FOCUS mode\r\n");
                    Light_SetMode(MODE_FOCUS);
                    break;
                case KEY_MODE_RELAX:
                    printf("Switch to RELAX mode\r\n");
                    Light_SetMode(MODE_RELAX);
                    break;
                case KEY_MODE_ENV:
                    printf("Switch to ENVIRONMENT mode\r\n");
                    Light_SetMode(MODE_ENVIRONMENT);
                    break;
                case KEY_MODE_PARTY:
                    printf("Switch to PARTY mode\r\n");
                    Light_SetMode(MODE_PARTY);
                    break;
            }
        }
        
        
        // 保持环境功能
        AppDisplay_Update();
        int temp = GetCurrentTemperature();
        int humi = GetCurrentHumidity();
        float air = GetCurrentAirQuality();
        Light_UpdateFromEnvironment(temp, humi, air);
        
        delay_ms(10);
    }
}

